# Padrões de Arquitetura — Novo Step
> Projeto: Migração RP Financeiro → Novo Step  
> Última atualização: 2026-04-30

---

## Stack Definida

### Frontend
| Lib | Uso |
|-----|-----|
| React + TypeScript | Framework base |
| PrimeReact | Componentes UI (DataTable, Dialog, etc.) |
| React Hook Form | Gerenciamento de formulários |
| Zod | Validação de schema (compartilhado front/back) |
| TanStack Query | Cache, loading, fetching de dados |

### Backend
| Lib | Uso |
|-----|-----|
| Node.js + TypeScript | Runtime |
| Fastify **ou** NestJS | Framework HTTP |
| Prisma | ORM + migrations |
| PostgreSQL | Banco de dados |
| Zod **ou** class-validator | Validação de DTOs |

---

## Padrão de Lista

### Árvore de componentes

```
Page
 └── ListShell
      ├── Header               ← título, breadcrumb
      ├── Toolbar
      │    ├── Botão "Novo"
      │    ├── Busca rápida     ← debounce 300ms
      │    └── Filtros avançados ← Dialog ou Sidebar
      ├── DataTable (PrimeReact)
      │    ├── Colunas          ← configuradas por entidade
      │    └── Row actions      ← editar, excluir
      ├── Paginação server-side  ← page, pageSize
      ├── Ordenação server-side  ← sortField, sortOrder
      ├── Estado: loading       ← skeleton ou spinner
      ├── Estado: vazio         ← mensagem + botão Novo
      └── Estado: erro          ← mensagem + retry
      └── Footer
```

### Contrato de API para listas

```typescript
// Query params esperados pelo backend
interface ListQuery {
  page: number;           // 1-indexed
  pageSize: number;       // default 20
  search?: string;        // busca global
  sortField?: string;
  sortOrder?: 'asc' | 'desc';
  [filter: string]: any;  // filtros específicos da entidade
}

// Resposta padrão do backend
interface ListResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}
```

### Exemplo de uso com TanStack Query

```typescript
// hooks/useClienteList.ts
export function useClienteList(query: ListQuery) {
  return useQuery({
    queryKey: ['clientes', query],
    queryFn: () => api.get('/clientes', { params: query }),
    placeholderData: keepPreviousData,   // evita flickering ao paginar
  });
}
```

### Skeleton do componente `ListShell`

```tsx
// components/ListShell.tsx
interface ListShellProps {
  title: string;
  onNew?: () => void;
  children: React.ReactNode;
}

export function ListShell({ title, onNew, children }: ListShellProps) {
  return (
    <div className="list-shell">
      <Header title={title} />
      <Toolbar onNew={onNew} />
      <div className="list-content">{children}</div>
      <Footer />
    </div>
  );
}
```

---

## Padrão de Formulário

### Árvore de componentes

```
Page
 └── FormShell
      ├── Header               ← título, breadcrumb
      ├── ActionsBar
      │    ├── Salvar           ← submit do form
      │    ├── Cancelar         ← volta para lista
      │    └── Excluir          ← visível conforme permissão
      ├── FormProvider          ← React Hook Form context
      ├── Seções / Abas         ← PrimeReact TabView se necessário
      │    └── Campos padronizados
      ├── Validação Zod
      └── Mensagens de erro     ← campo a campo + toast global
```

### Schema Zod compartilhado (front + back)

```typescript
// schemas/cliente.schema.ts  ← importado por frontend E backend

import { z } from 'zod';

export const ClienteSchema = z.object({
  tipo_pessoa: z.enum(['F', 'J']),
  razao_social: z.string().min(1, 'Campo obrigatório'),
  cnpj: z.string()
    .optional()
    .refine((val) => !val || validarCNPJ(val), 'CNPJ inválido'),
  cpf: z.string()
    .optional()
    .refine((val) => !val || validarCPF(val), 'CPF inválido'),
  email: z.string().email('E-mail inválido').optional().or(z.literal('')),
  cep: z.string().length(8, 'CEP deve ter 8 dígitos').optional(),
  // ... demais campos
}).superRefine((data, ctx) => {
  if (data.tipo_pessoa === 'J' && !data.cnpj) {
    ctx.addIssue({ code: 'custom', path: ['cnpj'], message: 'Campo obrigatório: CNPJ' });
  }
  if (data.tipo_pessoa === 'F' && !data.cpf) {
    ctx.addIssue({ code: 'custom', path: ['cpf'], message: 'Campo obrigatório: CPF' });
  }
});

export type ClienteFormData = z.infer<typeof ClienteSchema>;
```

### Exemplo de uso com React Hook Form

```typescript
// pages/clientes/ClienteForm.tsx
export function ClienteForm() {
  const form = useForm<ClienteFormData>({
    resolver: zodResolver(ClienteSchema),
    defaultValues: { tipo_pessoa: 'J' },
  });

  const mutation = useMutation({
    mutationFn: (data: ClienteFormData) => api.post('/clientes', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clientes'] });
      toast.success('Cliente salvo com sucesso!');
      navigate('/clientes');
    },
    onError: (err) => toast.error(err.message),
  });

  return (
    <FormProvider {...form}>
      <FormShell
        title="Cliente"
        onSave={form.handleSubmit(mutation.mutate)}
        onCancel={() => navigate('/clientes')}
        isLoading={mutation.isPending}
      >
        {/* campos */}
      </FormShell>
    </FormProvider>
  );
}
```

### Skeleton do componente `FormShell`

```tsx
// components/FormShell.tsx
interface FormShellProps {
  title: string;
  onSave: () => void;
  onCancel: () => void;
  onDelete?: () => void;       // undefined = botão não aparece
  isLoading?: boolean;
  children: React.ReactNode;
}

export function FormShell({ title, onSave, onCancel, onDelete, isLoading, children }: FormShellProps) {
  return (
    <div className="form-shell">
      <Header title={title} />
      <ActionsBar
        onSave={onSave}
        onCancel={onCancel}
        onDelete={onDelete}
        isLoading={isLoading}
      />
      <div className="form-content">{children}</div>
    </div>
  );
}
```

---

## Campos Padronizados

Criar um `fieldset` de componentes reutilizáveis que encapsulam PrimeReact + React Hook Form:

```tsx
// components/fields/TextField.tsx
export function TextField({ name, label, required }: FieldProps) {
  const { control, formState: { errors } } = useFormContext();
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <div className="field">
          <label htmlFor={name}>{label}{required && ' *'}</label>
          <InputText id={name} {...field} className={errors[name] ? 'p-invalid' : ''} />
          {errors[name] && <small className="p-error">{errors[name]?.message as string}</small>}
        </div>
      )}
    />
  );
}
```

Campos necessários por padrão:
- `TextField` — texto simples
- `TextareaField` — texto longo
- `NumberField` — numérico com formatação BR
- `CurrencyField` — monetário (R$)
- `DateField` — calendário PrimeReact
- `SelectField` — dropdown com lookup assíncrono
- `MultiSelectField` — seleção múltipla
- `SwitchField` — boolean
- `FileField` — upload de arquivo (integrar com object storage)

---

## Padrão de Erro e Feedback

```typescript
// Erros de validação do backend (Zod)
// Resposta 422:
{
  "errors": [
    { "field": "cnpj", "message": "CNPJ já cadastrado." },
    { "field": "email", "message": "E-mail inválido." }
  ]
}

// No frontend: mapear de volta para os campos do form
const { setError } = useFormContext();
errors.forEach(({ field, message }) => setError(field, { message }));
```

---

## Padrão de Permissões no Frontend

Baseado no RBAC implementado no backend (ver `regras-negocio-grupo-usuario.md`):

```typescript
// hooks/usePermission.ts
export function usePermission(modulo: string) {
  const { permissions } = useAuth();
  return {
    canView:   permissions[modulo]?.consulta   ?? false,
    canCreate: permissions[modulo]?.inclusao   ?? false,
    canEdit:   permissions[modulo]?.alteracao  ?? false,
    canDelete: permissions[modulo]?.exclusao   ?? false,
    canExport: permissions[modulo]?.exportacao ?? false,
    canPrint:  permissions[modulo]?.impressao  ?? false,
  };
}

// Uso no FormShell:
const { canDelete, canEdit } = usePermission('clientes');
<FormShell
  onDelete={canDelete ? handleDelete : undefined}  // undefined = botão oculto
  // ...
/>
```

---

## Padrão de Auditoria Automática (Backend)

Mapeado do Scriptcase — preencher em **todo** insert/update:

```typescript
// prisma/middleware/audit.middleware.ts
export function auditMiddleware(context: RequestContext) {
  return prisma.$use(async (params, next) => {
    if (['create', 'update'].includes(params.action)) {
      const auditFields = {
        id_usuario_auditoria:     context.userId,
        endereco_ip_auditoria:    context.ip,
        nome_aplicacao_auditoria: 'novo-step',
      };
      if (params.action === 'create') {
        params.args.data = { ...params.args.data, ...auditFields };
      } else {
        params.args.data = { ...params.args.data, ...auditFields };
      }
    }
    return next(params);
  });
}
```

---

## Padrão de Upload de Arquivos

Extraído do Scriptcase — todos os módulos com arquivo seguem:

| Campo DB | Conteúdo |
|----------|----------|
| `nome_arquivo` | Nome original do arquivo |
| `nome_referencia` | Nome hasheado no storage (`uuid.ext`) |

```typescript
// services/storage.service.ts
export async function uploadFile(file: Buffer, originalName: string, tenancyId: number): Promise<{ nomeArquivo: string; nomeReferencia: string }> {
  const ext = path.extname(originalName);
  const storageKey = `${tenancyId}/${crypto.randomUUID()}${ext}`;
  await s3.putObject({ Key: storageKey, Body: file });
  return {
    nomeArquivo:    originalName,
    nomeReferencia: storageKey,
  };
}
```

---

## Checklist de Implementação por Entidade

Para cada entidade, implementar nesta ordem:

```
[ ] Schema Zod compartilhado (schemas/{entidade}.schema.ts)
[ ] Endpoint GET /entidades        → ListResponse<T>
[ ] Endpoint GET /entidades/:id    → T
[ ] Endpoint POST /entidades       → T
[ ] Endpoint PUT /entidades/:id    → T
[ ] Endpoint DELETE /entidades/:id → void
[ ] Middleware de auditoria aplicado
[ ] Validação de fechamento financeiro (se aplicável)
[ ] Regras de negócio do onBeforeInsert mapeadas
[ ] Regras de negócio do onBeforeUpdate mapeadas
[ ] Hooks post-save (onAfterInsert equivalentes)
[ ] Componente ListPage
[ ] Componente FormPage
[ ] Hook usePERMISSÃO aplicado
[ ] Testes unitários das regras de negócio críticas
```
