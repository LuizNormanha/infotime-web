# Índice de Specs — Migração RP Financeiro → Novo Step
> Gerado em: 2026-04-30  
> Escopo: Extração de regras de negócio do Scriptcase → Node.js + Prisma  
> **40 entidades | "pacientes" = clientes neste sistema**

---

## Status Geral

| # | Entidade | Arquivo de Spec | Módulo | Prioridade |
|---|----------|----------------|--------|-----------|
| 1 | Agenda | [regras-negocio-agenda.md](./regras-negocio-agenda.md) | CRM | Média |
| 2 | Almoxarifado — Baixa | [regras-negocio-almoxarifado-baixa.md](./regras-negocio-almoxarifado-baixa.md) | ALM | Média |
| 3 | Almoxarifado — Entrada | [regras-negocio-almoxarifado-entrada.md](./regras-negocio-almoxarifado-entrada.md) | ALM | Média |
| 4 | Almoxarifado — Requisição | [regras-negocio-almoxarifado-requisicao.md](./regras-negocio-almoxarifado-requisicao.md) | ALM | Média |
| 5 | Almoxarifado — Config/Estoque | [regras-negocio-almoxarifado.md](./regras-negocio-almoxarifado.md) | ALM | Média |
| 6 | Aplicação (catálogo de módulos) | [regras-negocio-aplicacao.md](./regras-negocio-aplicacao.md) | SYS | Alta |
| 7 | Auditoria | [regras-negocio-auditoria.md](./regras-negocio-auditoria.md) | SYS | Alta |
| 8 | Auth (login/sessão) | [regras-negocio-auth.md](./regras-negocio-auth.md) | SYS | **Crítica** |
| 9 | Avaliação InfoLAB | [regras-negocio-avaliacao-infolab.md](./regras-negocio-avaliacao-infolab.md) | CRM | Baixa |
| 10 | Banco / Agência / Cartão | [regras-negocio-banco.md](./regras-negocio-banco.md) | FIN | Alta |
| 11 | Boleto Bancário | [regras-negocio-boleto.md](./regras-negocio-boleto.md) | FIN | **Crítica** |
| 12 | Cargo / Salário | [regras-negocio-cargo.md](./regras-negocio-cargo.md) | RH | Média |
| 13 | **Cliente** _(≡ paciente)_ | [regras-negocio-cliente.md](./regras-negocio-cliente.md) | CRM | **Crítica** |
| 14 | Cliente — Licença | [regras-negocio-cliente-licenca.md](./regras-negocio-cliente-licenca.md) | CRM | Alta |
| 15 | Colaborador | [regras-negocio-colaborador.md](./regras-negocio-colaborador.md) | RH | Alta |
| 16 | Colaborador — RH | [regras-negocio-colaborador-rh.md](./regras-negocio-colaborador-rh.md) | RH | Média |
| 17 | Colaborador — Tarefa | [regras-negocio-colaborador-tarefa.md](./regras-negocio-colaborador-tarefa.md) | OPS | Média |
| 18 | Colaborador — Viagem | [regras-negocio-colaborador-viagem.md](./regras-negocio-colaborador-viagem.md) | RH | Baixa |
| 19 | Concorrente | [regras-negocio-concorrente.md](./regras-negocio-concorrente.md) | CRM | Baixa |
| 20 | Configuração | [regras-negocio-configuracao.md](./regras-negocio-configuracao.md) | SYS | **Crítica** |
| 21 | Conta Caixa | [regras-negocio-conta-caixa.md](./regras-negocio-conta-caixa.md) | FIN | **Crítica** |
| 22 | Contrato | [regras-negocio-contrato.md](./regras-negocio-contrato.md) | CRM | **Crítica** |
| 23 | Empresa | [regras-negocio-empresa.md](./regras-negocio-empresa.md) | SYS | **Crítica** |
| 24 | Fornecedor | [regras-negocio-fornecedor.md](./regras-negocio-fornecedor.md) | FIN | Alta |
| 25 | Grupo de Usuário (RBAC) | [regras-negocio-grupo-usuario.md](./regras-negocio-grupo-usuario.md) | SYS | **Crítica** |
| 26 | Implantação | [regras-negocio-implantacao.md](./regras-negocio-implantacao.md) | OPS | Alta |
| 27 | Lançamento de Despesa | [regras-negocio-lancamento-despesa.md](./regras-negocio-lancamento-despesa.md) | FIN | **Crítica** |
| 28 | Lançamento de Receita | [regras-negocio-lancamento-receita.md](./regras-negocio-lancamento-receita.md) | FIN | **Crítica** |
| 29 | Negociação (CRM/Funil) | [regras-negocio-negociacao.md](./regras-negocio-negociacao.md) | CRM | Alta |
| 30 | Nota Fiscal (NFS-e) | [regras-negocio-nota-fiscal.md](./regras-negocio-nota-fiscal.md) | FIN | **Crítica** |
| 31 | Patrimônio | [regras-negocio-patrimonio.md](./regras-negocio-patrimonio.md) | OPS | Média |
| 32 | PIX | [regras-negocio-pix.md](./regras-negocio-pix.md) | FIN | **Crítica** |
| 33 | Plano de Contas / DRE | [regras-negocio-plano-conta.md](./regras-negocio-plano-conta.md) | FIN | **Crítica** |
| 34 | POP / Documento | [regras-negocio-pop-documento.md](./regras-negocio-pop-documento.md) | OPS | Baixa |
| 35 | Portal do Cliente | [regras-negocio-portal-cliente.md](./regras-negocio-portal-cliente.md) | CRM | Alta |
| 36 | Produto / Serviço | [regras-negocio-produto.md](./regras-negocio-produto.md) | CRM | Alta |
| 37 | Proposta Comercial | [regras-negocio-proposta.md](./regras-negocio-proposta.md) | CRM | **Crítica** |
| 38 | Retorno CNAB | [regras-negocio-retorno-cnab.md](./regras-negocio-retorno-cnab.md) | FIN | **Crítica** |
| 39 | Treinamento | [regras-negocio-treinamento.md](./regras-negocio-treinamento.md) | OPS | Baixa |
| 40 | Usuário | [regras-negocio-usuario.md](./regras-negocio-usuario.md) | SYS | **Crítica** |

---

## Legenda

| Símbolo | Prioridade |
|---------|-----------|
| **Crítica** | Bloqueia o MVP — deve ser implementado primeiro |
| Alta | Necessário no lançamento inicial |
| Média | Pode vir na segunda sprint pós-MVP |
| Baixa | Nice-to-have ou módulo opcional |

---

## Módulos

| Sigla | Módulo |
|-------|--------|
| SYS | Sistema (infra, auth, config) |
| CRM | Clientes, negócios, contratos |
| FIN | Financeiro |
| RH | Recursos Humanos |
| ALM | Almoxarifado |
| OPS | Operações / Implantação |

---

## Convenções dos Specs

| Prefixo | Categoria |
|---------|-----------|
| `V-INS-` | Validação antes de inserir |
| `V-UPD-` | Validação antes de atualizar |
| `C-` | Cálculo automático |
| `P-` | Preenchimento automático |
| `B-` | Regra de backend |
| `F-` | Regra de frontend |
| `D-` | Duvidosa — requer validação humana |
| `ERR-` | Mensagem de erro |
| `PERM-` | Regra de permissão |

---

## ⚠️ Itens de Atenção Transversais

1. **Senha MD5 → bcrypt**: Auth e Usuário — migração obrigatória
2. **Bytea → Object Storage**: Colaborador, Empresa, Patrimônio, POP, Contrato
3. **Tenacidade (multi-tenant)**: presente em todas as tabelas — mapear para middleware
4. **Auditoria transversal**: quando `configuracao.gravar_auditoria='S'` — implementar como interceptor global
5. **Fechamento financeiro**: bloquear alterações em Receita e Despesa — validar no service layer
6. **"Pacientes" = Clientes**: esta base usa o termo "cliente" — todo o código e documentação deve usar esta nomenclatura

---

## 🔁 REGRA TRANSVERSAL — Auditoria Automática (TODOS os formulários)

Detectada em **todos os** `onBeforeInsert` e `onBeforeUpdate` de todas as entidades:

```php
$this->idusuarioauditoria   = $this->sc_temp_varIdUsuario;
$this->enderecoipauditoria  = $_SERVER['REMOTE_ADDR'];
$this->nomeaplicacaoauditoria = $this->Ini->nm_cod_apl;
```

**Implementar no Node.js como Prisma middleware:**
```typescript
prisma.$use(async (params, next) => {
  if (['create', 'update'].includes(params.action)) {
    params.args.data = {
      ...params.args.data,
      id_usuario_auditoria: context.userId,
      endereco_ip_auditoria: context.ip,
      nome_aplicacao_auditoria: 'novo-step',
    };
  }
  return next(params);
});
```

---

## 📁 PADRÃO TRANSVERSAL — Upload de Arquivos

Detectado em: cliente, fornecedor, empresa, colaborador, nota-fiscal, proposta, contrato, pop-documento, colaborador-rh, colaborador-viagem, etc.

**Lógica Scriptcase:**
1. `nomearquivo` = nome original do arquivo
2. `nomereferencia` = `md5(date('YdmHisu') + nome + idTenacidade) + .extensao` (nome no storage)
3. `onBeforeInsert/Update`: gerar novo nome hash
4. `onAfterInsert/Update`: `rename(caminho_original, caminho_hasheado)` — move arquivo para nome definitivo

**Implementar no Node.js:**
```typescript
// Usar multer + S3/MinIO com UUID como nome de storage
const storageKey = `${tenancyId}/${crypto.randomUUID()}.${ext}`;
```
