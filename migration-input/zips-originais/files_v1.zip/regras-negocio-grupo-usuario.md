# Regras de Negócio — Grupo de Usuário (RBAC)
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `grupo-usuario`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ✅ Sim | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Nome do grupo único por tenacidade

---

## 3. Validações antes de Atualizar

*Mesmas validações de inserção aplicam-se na atualização.*

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

*Nenhum identificado.*

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT COUNT(*) AS countTest FROM
```

```sql
SELECT COUNT(*) AS countTest FROM grupousuarioaplicacao WHERE IdGrupoUsuario =
```

```sql
SELECT COUNT(*) AS countTest FROM grupousuarioaplicacao_ WHERE IdGrupoUsuario =
```

```sql
SELECT COUNT(*) AS countTest FROM grupousuarioaplicacaobloco WHERE IdGrupoUsuario =
```



---

## 7. Regras de Permissão

- Apenas administradores gerenciam grupos e permissões

---

## 8. Mensagens de Erro

*Nenhuma mensagem específica identificada além das validações.*

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `grupo_usuario`, `grupo_usuario_aplicacao`, `grupo_usuario_aplicacao_bloco`, `grupo_usuario_aplicacao_campo`

**Depende de:** `usuario`, `aplicacao`

---

## 11. Regras → Backend (Node.js + Prisma)

1. RBAC aditivo: usuário recebe a UNIÃO das permissões de todos os seus grupos
2. `administrador='sim'` no usuário: bypass total de todas as verificações RBAC
3. 3 níveis de granularidade: aplicação (CRUD) → bloco (seção da tela) → campo (visibilidade)
4. `onAfterInsert` grupo: criar mapa padrão de permissões para novas aplicações
5. Cache de permissões recomendado (Redis, TTL curto)
6. `onLoadRecord` campo detectado — provavelmente carrega permissões existentes no formulário

---

## 12. Regras → Frontend

1. Interface de gerenciamento de permissões por grupo (matrix aplicação × CRUD)
2. Preview de permissões do usuário resultante da combinação de grupos

---

## 13. Regras Duvidosas — Validação Humana

1. Conflito de permissões entre grupos: aditivo ou o mais restritivo prevalece?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
