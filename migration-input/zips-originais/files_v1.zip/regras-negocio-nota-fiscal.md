# Regras de Negócio — Nota Fiscal de Serviço (NFS-e)
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `nota-fiscal`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ✅ Sim | Validação do formulário |
| `onValidateSuccess` | ✅ Sim | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ✅ Sim | Após atualizar |
| `onRecord` | ✅ Sim | Botão de ação por registro |
| `onLoadRecord` | ⬜ Não detectado | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Empresa com dados de NFS-e configurados (`empresa_nota_fiscal` preenchida)
2. Lançamento de receita vinculado obrigatório

---

## 3. Validações antes de Atualizar

1. Nota emitida (com número) não pode ser editada — apenas cancelada

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

- Dados do cliente preenchidos automaticamente pelo `id_cliente`

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdTenacidade, NomeFantasia FROM tenacidade WHERE (IdTenacidade =
```

```sql
SELECT IdEmpresa, NomeFantasia FROM empresa WHERE (IdEmpresa =
```

```sql
SELECT IdUsuario, Nome FROM usuario WHERE (IdUsuario =
```

```sql
SELECT COUNT(*) AS countTest FROM
```

```sql
select count(*) AS countTest from " . $this->Ini->nm_tabela . " where IdEmpresaNotaFiscal = $this->idempresanotafiscal "
```



---

## 7. Regras de Permissão

- Emissão de NF requer permissão específica

---

## 8. Mensagens de Erro

- Empresa sem configuração de NFS-e
- Erro no webservice da prefeitura

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `nota_fiscal`, `empresa_nota_fiscal`

**Depende de:** `cliente`, `lancamento-receita`, `empresa`, `boleto`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Numeração: sequencial por empresa em `empresa_nota_fiscal.sequencial_nota_fiscal` com lock atômico
2. Emissão NFS-e: enviar XML assinado digitalmente ao webservice da prefeitura
3. Receber: `numero_lote`, `protocolo`, `numero_nota_fiscal_completo` da prefeitura
4. Cancelamento: comunicar prefeitura + registrar `id_usuario_cancelamento`
5. Vínculo: NF sempre ligada a um `lancamento_receita`
6. `onValidate`, `onBeforeInsert`, `onAfterInsert`, `onBeforeUpdate`, `onAfterUpdate` detectados
7. Botão 'ReplicarNotas' (`onRecord`) detectado — verificar funcionalidade

---

## 12. Regras → Frontend

1. Status da NFS-e com polling do webservice da prefeitura
2. Download do XML e DANFS-e

---

## 13. Regras Duvidosas — Validação Humana

1. Botão 'ReplicarNotas': replica notas de um período para outro? — verificar lógica

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
