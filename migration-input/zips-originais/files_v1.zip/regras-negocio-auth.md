# Regras de Negócio — Autenticação (Auth)
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `auth`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ⬜ Não detectado | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ⬜ Não detectado | Antes de inserir |
| `onAfterInsert` | ⬜ Não detectado | Após inserir |
| `onBeforeUpdate` | ⬜ Não detectado | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ⬜ Não detectado | Carregamento de registro |

---

## 2. Validações antes de Inserir

*Nenhuma identificada.*

---

## 3. Validações antes de Atualizar

*Mesmas validações de inserção aplicam-se na atualização.*

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

*Nenhum identificado.*

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT ENCODE($spswd, 'LIG@InfoL@BV3T
```

```sql
SELECT Email FROM usuario WHERE Login =
```

```sql
SELECT
			grupousuario.IdGrupoUsuario,
```

```sql
SELECT GROUP_CONCAT(a.IdSituacaoColaborador) FROM situacaocolaborador a WHERE a.Descricao IN (
```

```sql
SELECT group_concat(IdEmpresa) FROM empresa WHERE IdTenacidade =
```



---

## 7. Regras de Permissão

- Controle de acesso por empresa via `lista_empresa`

---

## 8. Mensagens de Erro

- Usuário ou senha incorretos
- Conta não ativada
- Conta inativa

---

## 9. Redirecionamentos

- Após login: redirecionar para home ou URL solicitada originalmente
- Usuário inativo: redirecionar para tela de acesso negado

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `usuario`

**Depende de:** `usuario`, `empresa`, `grupo-usuario`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Login único por tenacidade (UNIQUE INDEX em `usuario.login`)
2. MIGRAR hash de senha: MD5 legado → bcrypt com salt
3. `ativo = 'sim'` obrigatório para login; rejeitar com mensagem genérica
4. `administrador = 'sim'`: bypass total de RBAC
5. Ativação: gerar `codigo_ativacao` ao criar usuário; validar na primeira autenticação
6. Recuperação de senha: token com expiração de 24h; invalidar após uso
7. `lista_empresa` vazia = acesso a todas; caso contrário, filtrar por IDs

---

## 12. Regras → Frontend

1. Tela de login com suporte a recuperação de senha
2. Fluxo de ativação de cadastro via link de e-mail
3. Tela de alteração de senha obrigatória no primeiro acesso

---

## 13. Regras Duvidosas — Validação Humana

1. 2FA (autenticação de dois fatores): implementar no novo sistema? — validar com o time
2. Bloqueio por tentativas: quantas tentativas antes de bloquear conta?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
