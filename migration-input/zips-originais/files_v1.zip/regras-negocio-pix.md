# Regras de Negócio — PIX
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `pix`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ⬜ Não detectado | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ⬜ Não detectado | Antes de inserir |
| `onAfterInsert` | ⬜ Não detectado | Após inserir |
| `onBeforeUpdate` | ⬜ Não detectado | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ⬜ Não detectado | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Chave PIX da empresa configurada
2. TXID único (verificar antes de gravar)
3. Valor > 0

---

## 3. Validações antes de Atualizar

*Mesmas validações de inserção aplicam-se na atualização.*

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

*Nenhum identificado.*

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT RDB\$GET_CONTEXT('SYSTEM
```



---

## 7. Regras de Permissão

*Nenhum identificado.*

---

## 8. Mensagens de Erro

- Chave PIX não configurada
- TXID duplicado

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `pix`, `retorno_api_pix`

**Depende de:** `lancamento-receita`, `empresa`, `banco`

---

## 11. Regras → Backend (Node.js + Prisma)

1. TXID: 26 a 35 caracteres alfanuméricos, único por cobrança
2. Webhook: validar certificado SSL + assinatura do payload antes de processar
3. Idempotência: verificar `e2e_id` antes de baixar (`e2e_id` único)
4. Ao receber webhook: baixar `lancamento_receita` correspondente via `txid`
5. OAuth 2.0 + certificado mTLS para autenticação com API do Itaú
6. Cobrança imediata (`cob`) vs. com vencimento (`cobv`) vs. PIX direto

---

## 12. Regras → Frontend

1. Exibir QR Code PIX para o cliente pagar
2. Status da cobrança atualizado em tempo real via polling/webhook

---

## 13. Regras Duvidosas — Validação Humana

1. Ambiente sandbox × produção: como configurar chaveamento? — verificar `configuracao`

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
