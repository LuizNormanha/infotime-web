# Regras de Negócio — Lançamento de Receita
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `lancamento-receita`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ✅ Sim | Validação do formulário |
| `onValidateSuccess` | ✅ Sim | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ✅ Sim | Após atualizar |
| `onRecord` | ✅ Sim | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Cliente obrigatório
2. Conta caixa obrigatória
3. Plano de conta obrigatório
4. Valor previsão > 0
5. Data previsão obrigatória

---

## 3. Validações antes de Atualizar

1. Bloquear alteração de lançamentos em período com `fechamento_financeiro`
2. Não alterar lançamentos já baixados sem reversão explícita

---

## 4. Cálculos Automáticos

- valor_realizacao = valor_previsao + juros + multa + acréscimos - descontos

---

## 5. Preenchimentos Automáticos

- Parcelamento: calcular datas automaticamente

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdSituacaoDocumento, Descricao  FROM situacaodocumento  where IdTenacidade =
```

```sql
SELECT RDB\$GET_CONTEXT('SYSTEM
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT nf.NomeReferencia, nf.NomeArquivo, ct.email, cl.NomeFantasia, nf.NomeArquivoBoleto, nf.NomeReferenciaXml, cl.Cnpj
```

```sql
select = "SELECT ValorPrevisao, DataPrevisao, NotaFiscal, IdSituacaoDocumento, DataCompetencia FROM lancamentoreceita WHERE IdLancamentoReceita = ".$varIdReceita[$x]
```



---

## 7. Regras de Permissão

- Acesso por conta caixa via `conta_caixa_usuario`

---

## 8. Mensagens de Erro

- Período financeiro fechado
- Soma do rateio diferente do valor total

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `lancamento_receita`, `lancamento_receita_rateio`

**Depende de:** `cliente`, `conta-caixa`, `plano-conta`, `nota-fiscal`, `empresa`, `boleto`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Parcelamento: criar N lançamentos filhos com `id_lancamento_receita_pai`; incrementar datas
2. Recorrência: `id_lancamento_receita_recorrente` template; job cron gera lançamentos futuros
3. Baixa: atualizar `data_realizacao`, `valor_realizacao`, `data_baixa`, `idusuario_baixa`; mudar situação
4. Se boleto vinculado: baixar boleto junto com o lançamento
5. E-mail de cobrança: enviar para contato com `recebe_cobranca='S'`; registrar em `email_enviado`
6. Rateio: soma dos valores de `lancamento_receita_rateio` deve = `valor_previsao`
7. Fechamento financeiro: bloquear alteração de lançamentos em período fechado
8. `onValidate`, `onBeforeInsert`, `onBeforeUpdate` detectados
9. Botões `onRecord` detectados: 'EnviarEmails', 'Recorrente' — mapear funcionalidades

---

## 12. Regras → Frontend

1. Fluxo de baixa com modal de confirmação de valor e data
2. Exibir status de e-mail de cobrança (enviado/lido)
3. Configuração de recorrência com preview das próximas datas

---

## 13. Regras Duvidosas — Validação Humana

1. Baixa com valor diferente do previsto: aceitar com justificativa ou bloquear?
2. Rateio obrigatório ou opcional? — verificar configuração

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
