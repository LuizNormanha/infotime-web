# Regras de Negócio — Contrato
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `contrato`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

*Nenhuma identificada.*

---

## 3. Validações antes de Atualizar

1. Cancelamento: `motivo_cancelamento` obrigatório
2. Não permitir ativar item já encerrado

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

- Ao selecionar índice de reajuste: mostrar percentual histórico

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdCliente, NomeFantasia FROM cliente WHERE (IdCliente = " . $_SESSION[
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT IdEmpresa, NomeFantasia  FROM empresa  WHERE IdTenacidade =
```

```sql
SELECT IdTipoContrato, Descricao  FROM tipocontrato  WHERE Categoria =
```

```sql
SELECT IdIndiceReajuste, Descricao  FROM indicereajuste  WHERE     IdTenacidade =
```



---

## 7. Regras de Permissão

- Cancelamento requer permissão especial

---

## 8. Mensagens de Erro

- Motivo de cancelamento obrigatório

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `contrato`, `contrato_item`, `tipo_contrato`

**Depende de:** `cliente`, `proposta`, `empresa`, `produto`, `indice-reajuste`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Criado a partir de proposta aceita: copiar dados de `proposta` e `proposta_item`
2. Cancelamento obrigatório: `data_cancelamento` + `motivo_cancelamento` + `id_usuario_cancelamento`
3. `onBeforeUpdate` detectado — verificar lógica de validação ao atualizar
4. Reajuste: buscar percentual em `indice_reajuste_data` pela data de referência e aplicar em `contrato_item.valor_unitario`
5. Gerar lançamentos de receita mensais no `dia_vencimento` com base nos itens ativos
6. Ao criar contrato: disparar criação de tarefas de implantação para os produtos

---

## 12. Regras → Frontend

1. Exibir linha do tempo do ciclo de vida do contrato
2. Bloquear campos após cancelamento

---

## 13. Regras Duvidosas — Validação Humana

1. `arquivo` do contrato em bytea no legado — migrar para object storage
2. Reajuste em cascata para lançamentos futuros já gerados?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
