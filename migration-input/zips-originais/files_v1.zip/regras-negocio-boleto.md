# Regras de Negócio — Boleto Bancário
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `boleto`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ⬜ Não detectado | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ⬜ Não detectado | Antes de inserir |
| `onAfterInsert` | ⬜ Não detectado | Após inserir |
| `onBeforeUpdate` | ⬜ Não detectado | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ⬜ Não detectado | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Data de vencimento obrigatória
2. Valor > 0
3. Banco com dados de boleto configurados (`convenio_boleto` preenchido)

---

## 3. Validações antes de Atualizar

*Mesmas validações de inserção aplicam-se na atualização.*

---

## 4. Cálculos Automáticos

- valor_com_juros = valor_original + (valor_original × percentual_por_dia_juros × dias_atraso / 100)
- valor_com_multa = valor_com_juros + (valor_original × percentual_multa / 100)

---

## 5. Preenchimentos Automáticos

- Preencher dados bancários automaticamente ao selecionar conta caixa

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT RDB\$GET_CONTEXT('SYSTEM
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT NomeFantasia, IdCliente FROM cliente WHERE (#lowerI##cmp_iNomeFantasia#cmp_f)#cmp_apos LIKE #lowerI#
```

```sql
SELECT Descricao, IdSituacaoDocumento FROM situacaodocumento WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```



---

## 7. Regras de Permissão

*Nenhum identificado.*

---

## 8. Mensagens de Erro

- Banco sem convênio de boleto configurado

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `boleto`, `boleto_nota_fiscal`

**Depende de:** `lancamento-receita`, `banco`, `nota-fiscal`, `cliente`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Gerar `nosso_numero` sequencial único por banco/carteira (atomic increment)
2. Calcular `codigo_barras` conforme padrão CNAB do banco selecionado
3. Cálculo de juros: `percentual_por_dia_juros` × dias_atraso × valor_original
4. Cálculo de multa: `percentual_multa` × valor_original (cobrada uma única vez)
5. Baixa via CNAB: cruzar `nosso_numero` e atualizar situação + `data_pagamento`
6. Idempotência: não baixar mesmo boleto duas vezes

---

## 12. Regras → Frontend

1. Geração de PDF do boleto via template de impressão
2. Exibir linha digitável formatada

---

## 13. Regras Duvidosas — Validação Humana

1. Cancelamento de boleto: comunicar ao banco ou apenas marcar internamente?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
