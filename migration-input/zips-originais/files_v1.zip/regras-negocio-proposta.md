# Regras de Negócio — Proposta Comercial
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `proposta`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ✅ Sim | Validação do formulário |
| `onValidateSuccess` | ✅ Sim | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ✅ Sim | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Pelo menos um item na proposta
2. `valor_desconto_unico` ≤ `usuario.desconto_maximo_imp`
3. `valor_desconto_mensal` ≤ `usuario.desconto_maximo_mes`

---

## 3. Validações antes de Atualizar

1. Proposta aceita (`situacao='F'`): não permitir edição de itens

---

## 4. Cálculos Automáticos

- valor_total_implantacao = Σ(proposta_item.valor_unitario × qtd) - valor_desconto_unico
- valor_total_mensal = Σ(proposta_item.valor_mensalidade × qtd) - valor_desconto_mensal
- data_expiracao = data_inclusao + dias_validade

---

## 5. Preenchimentos Automáticos

- Ao selecionar cliente: preencher dados de contato do signatário
- Ao adicionar produto: preencher preço padrão do produto

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdCliente, Descricao FROM clienteempresa_view WHERE (IdTenacidade =
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT IdPropostaItem FROM propostaitem WHERE IdTenacidade =
```

```sql
SELECT IdEmpresa, RazaoSocial  FROM empresa WHERE IdTenacidade =
```

```sql
SELECT IdTipoContrato, Descricao  FROM tipocontrato  WHERE IdTenacidade =
```



---

## 7. Regras de Permissão

- Colaborador vê apenas suas próprias propostas; gerente vê da equipe

---

## 8. Mensagens de Erro

- Desconto excede o limite autorizado para seu perfil

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `proposta`, `proposta_item`, `proposta_fase`, `indice_reajuste`, `indice_reajuste_data`

**Depende de:** `cliente`, `produto`, `colaborador`, `tipo_contrato`, `negociacao`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Desconto máximo: `valor_desconto_unico` ≤ `usuario.desconto_maximo_imp` %; `valor_desconto_mensal` ≤ `desconto_maximo_mes` %
2. Se ultrapassar limite: exigir autorização de superior (`acesso_autorizacoes='S'`)
3. Conversão em contrato: proposta aceita → gerar `contrato` + `contrato_item` automaticamente
4. Validade: calcular `data_expiracao = data_inclusao + dias_validade`
5. `onValidate`, `onBeforeInsert`, `onAfterInsert`, `onBeforeUpdate`, `onAfterUpdate` detectados
6. Gerar PDF com template de `tipo_contrato.nome_arquivo`

---

## 12. Regras → Frontend

1. Calculadora de totais com descontos em tempo real
2. Alerta visual quando desconto excede o limite do usuário
3. Preview e download de PDF da proposta

---

## 13. Regras Duvidosas — Validação Humana

1. Proposta expirada: bloquear conversão ou apenas alertar?
2. Reajuste de proposta: aplicar índice nos itens antes de converter?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |
