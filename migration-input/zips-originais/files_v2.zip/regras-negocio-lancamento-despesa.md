# Regras de Negócio — Lançamento de Despesa
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `lancamento-despesa`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ✅ Sim | Validação do formulário |
| `onValidateSuccess` | ✅ Sim | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ✅ Sim | Após atualizar |
| `onRecord` | ✅ Sim | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Conta caixa obrigatória
2. Plano de conta obrigatório
3. Valor previsão > 0
4. Data previsão obrigatória

---

## 3. Validações antes de Atualizar

1. Bloquear edição em período com `fechamento_financeiro`
2. Transição de workflow: estágios devem ser respeitados em ordem

---

## 4. Cálculos Automáticos

- Parcelamento: valor_parcela = valor_total / qtd_parcelas
- Datas das parcelas: data_previsao + (n × intervalo_dias)

---

## 5. Preenchimentos Automáticos

- Ao selecionar fornecedor: sugerir plano de conta de `fornecedor_plano_conta`

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT RDB\$GET_CONTEXT('SYSTEM
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT Descricao, IdContaCaixa FROM contacaixa WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```

```sql
SELECT Descricao, IdSituacaoDocumento FROM situacaodocumento WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```

```sql
SELECT Descricao, IdPlanoConta FROM planoconta WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```



---

## 7. Regras de Permissão

- Acesso a conta caixa via `conta_caixa_usuario`

---

## 8. Mensagens de Erro

- Período financeiro fechado — não é possível alterar este lançamento

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `lancamento_despesa`, `lancamento_despesa_rateio`

**Depende de:** `fornecedor`, `conta-caixa`, `plano-conta`, `empresa`, `cheque`, `almoxarifado-entrada`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Workflow 5 estágios: Inclusão → Previsão → Agendamento → Realização → Baixa (cada com usuário + data)
2. Parcelamento: gerar N lançamentos filhos vinculados por `id_lancamento_despesa_pai`
3. Recorrência: job cron para geração automática de lançamentos futuros
4. Fechamento financeiro: bloquear alterações em `fechamento_financeiro='S'`
5. Rateio: `lancamento_despesa_rateio` — soma deve = valor total (validar no backend)
6. `onValidate`, `onBeforeInsert`, `onAfterInsert`, `onBeforeUpdate`, `onAfterUpdate` detectados
7. Vínculo com almoxarifado: `id_almoxarifado_entrada` quando origina de NF de entrada
8. Botão 'Gerar' (`onRecord`) detectado — provavelmente gera parcelamento ou recorrência

---

## 12. Regras → Frontend

1. Exibir stepper do workflow de 5 estágios
2. Parcelamento: informar número de parcelas e calcular datas automaticamente

---

## 13. Regras Duvidosas — Validação Humana

1. `onValidate` detectado mas sem código visível — verificar arquivos PHP manualmente
2. Rateio: soma das parcelas de rateio deve = 100% ou = valor_total?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |


---

## ⚡ REGRAS ADICIONAIS EXTRAÍDAS DO CÓDIGO PHP

### `onValidate` — LancamentoDespesa_Frm_apl.php (CRÍTICO)
- Se `fechamentofinanceiro == 'S'` → **erro**: "Despesa não pode ser alterada. Já houve fechamento financeiro para esse período."
- Se não fechado ainda: consultar `fechamentofinanceiro` WHERE `DataInicial <= dataprevisao <= DataFinal` — se encontrar, também bloquear

### `onValidateSuccess` — LancamentoDespesa_Frm_apl.php
- Se `idtipoespecie == 1` (Cheque) E `idcheque` vazio → **erro** "Campo obrigatório: Cheque"
- Se `idsituacaodocumento == 4` (Baixado): obrigatórios: `valorrealizacao`, `datarealizacao`, `idtipoespecie`, `databaixa`
- Mensagens específicas: "Valor pago: Campo obrigatório", "Pago em: Campo obrigatório", "Espécie: Campo obrigatório", "Baixado em: Campo obrigatório"

### `onAfterInsert/Update` — LancamentoDespesa_Frm_apl.php
- Se `idtipoespecie IN (1, 102)` E `idcheque` preenchido E `idsituacaodocumento == 4` → chamar `AtualizarCheque()` (atualiza situação do cheque)

### `onBeforeInsert` — LancamentoDespesa_Frm_apl.php
- Se boleto novo → `idsituacaodocumento == 73`: mudar para `idsituacaodocumento = 1` (boleto pendente → aguardando pagamento)
- Renomear arquivos de upload: boleto, NF, comprovante, anexo com hash MD5

### Rateio — LancamentoDespesaRateio_Gde_apl.php
- `onValidate`: `valorrateio > valor_da_parcela` → **erro** "Valor do rateio é maior que o valor da parcela."
- `onAfterInsert/Update`: chamar `validarRateio()` — valida soma total
- `onAfterDelete`: marcar rateios como `Validado = 'N'`
- Bloqueio de edição: se rateio já validado (`Validado = 'S'`) → desabilitar campos
- Bloqueio se despesa já baixada: ocultar botões de new/insert/update/delete

### Padrão de exibição por TipoAgente
- Tipo 1 (Cliente): mostrar `idcliente` + `idplanocontacliente`; ocultar fornecedor/colaborador
- Tipo 2 (Fornecedor): mostrar `idfornecedor` + `idplanoconta`; ocultar cliente/colaborador
- Tipo 3 (Colaborador): mostrar `idcolaborador` + `idplanocontacolaborador`; ocultar cliente/fornecedor

