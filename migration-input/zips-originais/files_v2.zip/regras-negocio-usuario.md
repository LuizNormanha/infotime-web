# Regras de Negócio — Usuário do Sistema
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `usuario`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ⬜ Não detectado | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ⬜ Não detectado | Botão de ação por registro |
| `onLoadRecord` | ⬜ Não detectado | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. Login único por tenacidade
2. `lista_empresa` vazia = acesso a todas (padrão para novos usuários)

---

## 3. Validações antes de Atualizar

*Mesmas validações de inserção aplicam-se na atualização.*

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

*Nenhum identificado.*

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT COUNT(*) AS countTest FROM
```

```sql
select count(*) AS countTest from " . $this->Ini->nm_tabela . " where IdUsuario = $this->idusuario "
```

```sql
select count(*) AS countTest from " . $this->Ini->nm_tabela . " where IdUsuario = $this->idusuario ")
```

```sql
select max(IdUsuario) from " . $this->Ini->nm_tabela
```



---

## 7. Regras de Permissão

- Apenas administradores gerenciam usuários

---

## 8. Mensagens de Erro

- Login já existe no sistema

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `usuario`

**Depende de:** `empresa`, `grupo-usuario`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Login único por tenacidade (UNIQUE INDEX)
2. Senha: MD5 no legado → **migrar para bcrypt** na criação/alteração
3. Ao criar: associar a grupos; enviar e-mail com senha inicial ou link de ativação
4. `desconto_maximo_imp` e `desconto_maximo_mes`: validados nas propostas
5. `administrador='sim'`: bypass total de RBAC
6. SQL detectado: busca por `aplicacao` ao criar usuário — mapear para lookup de módulos
7. `onAfterInsert` detectado — provavelmente envia e-mail de boas-vindas

---

## 12. Regras → Frontend

1. Formulário com associação de grupos por lista multipla seleção
2. Indicadores de permissões especiais (financeiro, auditoria, autorizações)

---

## 13. Regras Duvidosas — Validação Humana

1. Desativar usuário: revogar sessões ativas imediatamente?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |


---

## ⚡ REGRAS ADICIONAIS EXTRAÍDAS DO CÓDIGO PHP

### `onBeforeInsert` — Usuario_Frm_apl.php
- Validar `senha == confirm_pswd` → **erro** se diferente (mensagem da linguagem)
- Após validação: hash MD5 da senha (migrar para bcrypt)

### `onBeforeUpdate` — Usuario_Frm_apl.php
- Se `privAdmin == 1` E `novasenha` preenchido: hash MD5 e `UPDATE usuario SET Senha = X WHERE IdUsuario = Y` direto
- Campo `novasenha` só aparece para admins editando outros usuários

### `onLoad` — Usuario_Frm_apl.php
- Ocultar `novasenha` em novo cadastro (só na edição pelo admin)
- Usuário 1 (master): ocultar botões delete e update
- Se `IdTenacidade != 1`: ocultar campos de desconto máximo e zerá-los
- Se admin mas não usuário 1: campos de desconto habilitados apenas se valor > 1%

### `onScriptinit` — Usuario_Frm_apl.php
- Se `privAdmin != 1`: ocultar campos `administrador` e `novasenha`

### `onApplicationInit` — Usuario_Incluir_Frm_apl.php (ATIVAÇÃO)
- Se `?a=new_XXXX` (link de ativação): `UPDATE usuario SET Ativo = 'Y', CodigoAtivacao = '' WHERE CodigoAtivacao = X`
- Após ativação: redirecionar para login

### `onAfterInsert` — Usuario_Incluir_Frm_apl.php
- Redirecionar para tela de login após criar conta

