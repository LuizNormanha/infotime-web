# Regras de Negócio — Cliente
> Migração: Scriptcase → Node.js + Prisma  
> Projeto: RP Financeiro → Novo Step  
> Entidade: `cliente`  
> Última atualização: 2026-04-30

---

## 1. Eventos Scriptcase Encontrados

| Evento | Detectado | Observação |
|--------|-----------|-----------|
| `onLoad` | ✅ Sim | Inicialização do formulário |
| `onScriptInit` | ⬜ Não detectado | Inicialização do script |
| `onValidate` | ⬜ Não detectado | Validação do formulário |
| `onValidateSuccess` | ✅ Sim | Pós-validação com sucesso |
| `onBeforeInsert` | ✅ Sim | Antes de inserir |
| `onAfterInsert` | ✅ Sim | Após inserir |
| `onBeforeUpdate` | ✅ Sim | Antes de atualizar |
| `onAfterUpdate` | ⬜ Não detectado | Após atualizar |
| `onRecord` | ✅ Sim | Botão de ação por registro |
| `onLoadRecord` | ✅ Sim | Carregamento de registro |

---

## 2. Validações antes de Inserir

1. PJ: CNPJ válido (14 dígitos + validação) e `razao_social` obrigatória
2. PF: CPF válido (11 dígitos + validação), `sexo` e `data_nascimento` obrigatórios
3. `email` com formato válido se preenchido

---

## 3. Validações antes de Atualizar

1. Não permitir alterar `tipo_pessoa` se já existirem documentos vinculados

---

## 4. Cálculos Automáticos

*Nenhum identificado.*

---

## 5. Preenchimentos Automáticos

- CEP → logradouro, bairro, cidade, estado via API ViaCEP
- `tipo_pessoa='J'` → exibir campos CNPJ/Razão Social; `'F'` → CPF/Nome/Nascimento

---

## 6. SQLs Customizados

Consultas customizadas detectadas nos arquivos Scriptcase:

```sql
SELECT RDB\$GET_CONTEXT('SYSTEM
```

```sql
SELECT IdAplicacao FROM aplicacao WHERE Nome =
```

```sql
SELECT Descricao, IdSituacaoCliente FROM situacaocliente WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```

```sql
SELECT Descricao, IdTipoCliente FROM tipocliente WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```

```sql
SELECT Descricao, IdClienteCanal FROM clientecanal WHERE (#lowerI##cmp_iDescricao#cmp_f)#cmp_apos LIKE #lowerI#
```



---

## 7. Regras de Permissão

- Clientes filtrados por empresa do usuário logado

---

## 8. Mensagens de Erro

- CNPJ inválido
- CPF inválido
- CEP não encontrado

---

## 9. Redirecionamentos

*Nenhum redirecionamento customizado identificado.*

---

## 10. Dependências de Outras Tabelas

**Tabelas da entidade:** `cliente`, `cliente_contato`, `cliente_comunicacao`, `cliente_unidade`, `cliente_plano_conta`

**Depende de:** `situacao_cliente`, `tipo_cliente`, `cliente_canal`, `conta-caixa`, `municipio`, `concorrente`

---

## 11. Regras → Backend (Node.js + Prisma)

1. Pessoa Jurídica (`tipo_pessoa='J'`): CNPJ 14 dígitos, `razao_social` obrigatória
2. Pessoa Física (`tipo_pessoa='F'`): CPF 11 dígitos, `sexo` e `data_nascimento` obrigatórios
3. Hierarquia: `id_cliente_pai` para matriz/filial — validar que pai não é o próprio registro
4. Contato com `recebe_cobranca='S'`: incluir em lote de e-mails de cobrança
5. CEP: integrar com API ViaCEP `https://viacep.com.br/ws/{cep}/json/`
6. Chave de acesso ao portal: UUID gerado no backend
7. SQL list: filtros por `situacao_cliente`, `tipo_cliente`, `cliente_canal`

---

## 12. Regras → Frontend

1. Alternar campos CPF/CNPJ e campos PF/PJ conforme `tipo_pessoa`
2. Busca automática de endereço ao informar CEP
3. Validação de formato de CPF e CNPJ com dígitos verificadores

---

## 13. Regras Duvidosas — Validação Humana

1. CPF/CNPJ deve ser único no sistema ou pode haver duplicatas? — verificar constraint
2. `emite_boleto = 'S'`: quais regras extras isso ativa?

---

## 🔄 Histórico de Revisões

| Data | Autor | Alteração |
|------|-------|-----------|
| 2026-04-30 | Claude | Spec gerado automaticamente a partir dos fontes Scriptcase |


---

## ⚡ REGRAS ADICIONAIS EXTRAÍDAS DO CÓDIGO PHP

### `onBeforeInsert` — Cliente_Frm_apl.php
- **Geração de chave de acesso**: Se `IdTenacidade == 1` E `idsituacaocliente == 1`, gerar UUID via `md5(uniqid(rand(), true))` e salvar em `chaveacesso`
- **Implementar no backend**: `crypto.randomUUID()` ou `uuid` package

### `onBeforeUpdate` — Cliente_Frm_apl.php
- Se `clientepublico != 'S'` E `IdTenacidade == 1`:
  - Consultar `lancamentoreceita` com `IdSituacaoDocumento IN (238,1,73,2)` E `DataPrevisao < NOW()`
  - Se existir receita pendente E `data_expiracao` foi reduzida → **bloquear atualização** com erro
- Lógica: não permitir reduzir data de licença se há lançamentos pendentes

### `onScriptinit` — Cliente_Frm_apl.php
- Consultar `configuracao.ClienteConcorrente` para exibir/ocultar campo `idconcorrente`
- Implementar no frontend: verificar configuração ao carregar formulário

### `onValidateSuccess` — Cliente_Frm_apl.php
- Se `idsituacaocliente != 3` E CNPJ vazio → **erro**: "Campo obrigatório: CNPJ"
- CNPJ só é opcional para situação 3 (ex: "Lead" ou "Prospect")

### `onLoad` — ClienteUnidade_Frm_apl.php / Cliente_Frm_apl.php
- **PJ** (`tipopessoa = 'J'`): labels → "Razão social", "Nome fantasia", "CNPJ *", "Inscrição Estadual", "Inscrição Municipal"
- **PF** (`tipopessoa = 'F'`): labels → "Nome", "Apelido", "CPF", "Carteira de Identidade", "Orgão Emissor"
- Campos `sexo` e `datanascimento` ocultos para PJ; visíveis para PF

### `onBeforeInsert/Update` — ClienteSenha_Frm_apl.php
- Senha do portal do cliente: hash MD5 (⚠️ migrar para bcrypt)
- `nomereferencia` (upload): renomear arquivo com `md5(date + nome + tenacidade)` antes de salvar
- Padrão de upload de arquivo: `nomearquivo` = nome original; `nomereferencia` = nome hasheado no storage

### Regra transversal em TODOS os `onBeforeInsert/Update`
- Preencher automaticamente: `idusuarioauditoria = session.userId`, `enderecoipauditoria = REMOTE_ADDR`, `nomeaplicacaoauditoria = nm_cod_apl`
- **Implementar como middleware Prisma ou decorator de service**

